<!DOCTYPE html>
<html>
<head>
	<title>RTI FORM TRIAL</title>
</head>
<body>

	<form>
  First name:<br>
  <input type="text" name="firstname"><br>
  Last name:<br>
  <input type="text" name="lastname">
</form>
</body>
</html>