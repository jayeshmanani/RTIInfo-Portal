<!DOCTYPE html>
<html>

<body>


<!-- Footer --> 
      <footer id="footer">
        <div class="inner">
          <div class="content">
            
            <section>
              <h4>Menu</h4>
                <hr>
              <ul class="alt">
                <li><a href="index.php">Home</a></li>
                <li><a href="login.php">Apply Now</a></li>
                <li><a href="#">Find RTI</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
              </ul>
            </section>
            <section></section>
            <section>
              <h4>Social Media</h4>
              <ul class="plain">
                <li><a href="#"><i class="icon fa-twitter">&nbsp;</i>Twitter</a></li>
                <li><a href="#"><i class="icon fa-facebook">&nbsp;</i>Facebook</a></li>
                <li><a href="#"><i class="icon fa-instagram">&nbsp;</i>Instagram</a></li>
                <li><a href="#"><i class="icon fa-github">&nbsp;</i>Github</a></li>
              </ul>
            </section>
          </div>
          <div class="copyright">
            &copy; RTI<a href="home.php">info</a>, portal.
          </div>
        </div>
      </footer>  

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/browser.min.js"></script>
      <script src="assets/js/breakpoints.min.js"></script>
      <script src="assets/js/util.js"></script>
      <script src="assets/js/main.js"></script>
</body>
</html>